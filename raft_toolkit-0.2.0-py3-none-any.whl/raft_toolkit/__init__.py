"""RAFT Toolkit - Retrieval Augmented Fine-Tuning Dataset Generator."""

__version__ = "0.2.0"
