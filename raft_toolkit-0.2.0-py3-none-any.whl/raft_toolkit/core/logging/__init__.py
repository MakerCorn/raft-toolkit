"""
Logging configuration and setup for RAFT Toolkit.
"""

from .setup import log_setup

__all__ = ["log_setup"]
