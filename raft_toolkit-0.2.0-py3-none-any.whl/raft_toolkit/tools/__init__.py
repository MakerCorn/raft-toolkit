"""
Standalone tools and utilities for RAFT Toolkit.
"""
